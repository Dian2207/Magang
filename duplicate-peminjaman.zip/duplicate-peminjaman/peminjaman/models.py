# models.py
from datetime import date, datetime

from sqlalchemy import Date, DateTime, event
from extensions import db


# ---------- PEGAWAI ----------
class Pegawai(db.Model):
    __tablename__ = "pegawai"

    id = db.Column(db.Integer, primary_key=True)
    id_pegawai = db.Column(db.String(20), nullable=False)
    nama_pegawai = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)

    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(100), nullable=False, default="1234")

    role = db.Column(db.String(20), nullable=False, default="pegawai")

    profile_photo = db.Column(db.String(255), nullable=True)
    unit = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), nullable=False)

    no_telp = db.Column(db.String(20), nullable=True)

    created_at = db.Column(DateTime)
    updated_at = db.Column(DateTime)


@event.listens_for(Pegawai, "before_insert")
def pegawai_before_insert(mapper, connection, target):
    if not getattr(target, "username", None):
        nama = (target.nama_pegawai or "")
        target.username = nama.replace(" ", "").lower()

    if not getattr(target, "password", None):
        target.password = "1234"

    now = datetime.utcnow()
    if not getattr(target, "created_at", None):
        target.created_at = now
    target.updated_at = now


@event.listens_for(Pegawai, "before_update")
def pegawai_before_update(mapper, connection, target):
    target.updated_at = datetime.utcnow()


# ---------- PRODUCT ----------
class Product(db.Model):
    __tablename__ = "product"

    product_id = db.Column(db.String(50), primary_key=True)
    product_name = db.Column(db.String(150), nullable=False)
    product_desc = db.Column(db.Text)
    product_image = db.Column(db.String(255))
    quantity = db.Column(db.Integer, default=0)
    status = db.Column(db.String(30))
    uploaded_date = db.Column(Date, default=date.today)

    pengajuan_list = db.relationship(
        "Pengajuan",
        back_populates="product",
        lazy=True,
    )

    pengembalian_list = db.relationship(
        "Pengembalian",
        back_populates="product",
        lazy=True,
        cascade="all, delete-orphan",
    )


class ProductGallery(db.Model):
    __tablename__ = "product_gallery"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.String(50), db.ForeignKey("product.product_id"), nullable=False)
    image_path = db.Column(db.String(255), nullable=False)
    sort_order = db.Column(db.Integer, default=0)


# ---------- PENGAJUAN (tabel pengajuan1) ----------
class Pengajuan(db.Model):
    __tablename__ = "pengajuan1"

    id = db.Column(db.Integer, primary_key=True)
    nama_peminjam = db.Column(db.String(100), nullable=False)
    id_pegawai = db.Column(db.String(50), nullable=False)
    unit = db.Column(db.String(100), nullable=False)
    no_telp = db.Column(db.String(20), nullable=True)

    product_id = db.Column(db.String(50), db.ForeignKey("product.product_id"))
    nama_barang = db.Column(db.String(100), nullable=False)
    kategori_barang = db.Column(db.String(100), nullable=False)
    jumlah_unit = db.Column(db.Integer, nullable=False)
    ketersediaan = db.Column(db.Integer, nullable=False)
    keperluan = db.Column(db.Text, nullable=False)

    tanggal_mulai = db.Column(Date, nullable=False)
    tanggal_selesai = db.Column(Date, nullable=False)
    tanggal_input = db.Column(DateTime)
    status = db.Column(db.String(30), default="Menunggu")

    # relasi ke product
    product = db.relationship("Product", back_populates="pengajuan_list", lazy="joined")

    # relasi 1-1 ke pengembalian (pengembalian.pengajuan_id)
    pengembalian = db.relationship(
        "Pengembalian",
        back_populates="pengajuan",
        uselist=False,
        cascade="all, delete-orphan",
    )


# ---------- PENGEMBALIAN (tabel pengembalian) ----------
class Pengembalian(db.Model):
    __tablename__ = "pengembalian"

    id = db.Column(db.Integer, primary_key=True)

    pengajuan_id = db.Column(db.Integer, db.ForeignKey("pengajuan1.id"))
    product_id = db.Column(db.String(50), db.ForeignKey("product.product_id"))

    nama_peminjam = db.Column(db.String(100))
    id_pegawai = db.Column(db.String(50))
    unit = db.Column(db.String(100))
    no_telp = db.Column(db.String(20))

    nama_barang = db.Column(db.String(100), nullable=False)
    kategori_barang = db.Column(db.String(100))
    jumlah_unit = db.Column(db.Integer)
    ketersediaan = db.Column(db.Integer)
    keperluan = db.Column(db.Text)

    tanggal_mulai = db.Column(Date, nullable=False)
    tanggal_selesai = db.Column(Date, nullable=False)   # input user (rencana kembali)
    tanggal_kembali = db.Column(Date, nullable=True)    # diisi admin saat TERIMA

    durasi = db.Column(db.Integer)
    kondisi_barang = db.Column(db.String(120))
    foto_serah_terima = db.Column(db.String(255))
    status = db.Column(db.String(30))
    aksi_status = db.Column(db.String(30), nullable=True)

    pengajuan = db.relationship("Pengajuan", back_populates="pengembalian")
    product = db.relationship("Product", back_populates="pengembalian_list")
