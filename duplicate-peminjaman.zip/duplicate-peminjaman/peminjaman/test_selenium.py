from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

# Tentukan lokasi ChromeDriver menggunakan Service
service = Service(executable_path="C:/path/to/chromedriver.exe")  # Gantilah path dengan yang sesuai

# Setup opsi Chrome
chrome_options = Options()
chrome_options.add_argument("--headless")  # Menjalankan browser tanpa tampilan grafis

# Setup WebDriver
driver = webdriver.Edge(executable_path="C:/path/to/msedgedriver.exe")
driver.get("https://www.google.com")

assert "example" in driver.title

driver.quit()
