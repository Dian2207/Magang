# routes/admin_route.py
from flask import (
    Blueprint,
    flash,
    render_template,
    request,
    redirect,
    url_for,
    current_app,
    session,
)
from sqlalchemy import or_
from sqlalchemy.orm import joinedload
from models import Product, Pengajuan, Pengembalian, Pegawai, ProductGallery
from extensions import db
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash, generate_password_hash
from functools import wraps
from datetime import date
import os
from io import BytesIO
from flask import send_file
from reportlab.lib.pagesizes import A4, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
import requests
from twilio.rest import Client
from dotenv import load_dotenv
load_dotenv()

admin_bp = Blueprint(
    "admin_bp",
    __name__,
    static_folder="../static/static_admin",
    static_url_path="/static_admin",
    template_folder="../templates/admin",
)

# ==========================
# LOGIN GUARD (AUTO REDIRECT)
# ==========================
@admin_bp.before_request
def require_admin_login():
    endpoint = request.endpoint or ""

    # izinkan akses static file blueprint
    if endpoint == "admin_bp.static":
        return

    # izinkan akses login page (GET/POST)
    if endpoint == "admin_bp.login_admin":
        # kalau sudah login dan buka /login -> lempar ke beranda
        if request.method == "GET" and session.get("admin_id"):
            return redirect(url_for("admin_bp.home_admin"))
        return

    # izinkan logout kapan saja
    if endpoint == "admin_bp.logout_admin":
        return

    # selain itu wajib login
    if not session.get("admin_id"):
        return redirect(url_for("admin_bp.login_admin"))


def verify_password(stored_password: str, input_password: str) -> bool:
    if not stored_password:
        return False
    if stored_password.startswith("pbkdf2:") or stored_password.startswith("scrypt:"):
        return check_password_hash(stored_password, input_password)
    return stored_password == input_password


# ==========================
# LOGIN / LOGOUT
# ==========================
@admin_bp.route("/login", methods=["GET", "POST"])
def login_admin():
    # (backup) kalau sudah login jangan tampilkan login lagi
    if request.method == "GET" and session.get("admin_id"):
        return redirect(url_for("admin_bp.home_admin"))

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        # cari user berdasarkan username
        user = Pegawai.query.filter_by(username=username).first()

        if not user:
            return render_template(
                "admin/Login.html",
                error="Login gagal: akun bukan admin/super admin atau password salah.",
            )

        # --- normalisasi role ---
        role_val = (user.role or "").strip().lower()
        uname = (user.username or "").strip().lower()
        allowed_usernames = {"admin1", "admin2", "admin3", "superadmin"}
        is_admin_account = role_val in {"admin", "super_admin"} or uname in allowed_usernames

        # cek:
        # - akunnya admin
        # - password cocok (mendukung plaintext & hash)
        if is_admin_account and verify_password(user.password, password):
            # simpan session admin
            session.clear()
            session["admin_id"] = user.id
            session["admin_username"] = user.username
            session["admin_role"] = role_val or "admin"  # default 'admin' kalau kosong
            session["profile_photo"] = user.profile_photo

            # upgrade password plaintext -> hash (sekali saja)
            if user.password and not (
                user.password.startswith("pbkdf2:") or user.password.startswith("scrypt:")
            ):
                user.password = generate_password_hash(password)
                db.session.commit()

            return redirect(url_for("admin_bp.home_admin"))

        # kalau gagal salah satu (bukan admin / password salah)
        return render_template(
            "admin/Login.html",
            error="Login gagal: akun bukan admin/super admin atau password salah.",
        )

    # GET pertama kali
    return render_template("admin/Login.html")


@admin_bp.route("/logout")
def logout_admin():
    session.clear()
    return redirect(url_for("admin_bp.login_admin"))


# ==========================
# ROUTE ADMIN LAINNYA
# (BAGIAN BAWAH TETAP SAMA PUNYAMU)
# Karena sudah diproteksi otomatis oleh before_request di atas.
# ==========================
@admin_bp.route("/profile")
def profileAdmin():
    print("DEBUG FOTO SESSION =", session.get("profile_photo"))
    return render_template("admin/profileAdmin.html")


@admin_bp.route("/")
def home_admin():
    cnt_user = Pegawai.query.count()
    cnt_pengajuan = Pengajuan.query.count()
    cnt_product = Product.query.count()

    total = db.session.query(db.func.sum(Product.quantity)).scalar() or 0

    cnt_pin = (
        db.session.query(db.func.sum(Pengajuan.jumlah_unit))
        .filter(Pengajuan.status == "Dipinjam")
        .scalar()
        or 0
    )
    cnt_rus = (
        db.session.query(db.func.sum(Product.quantity)).filter_by(status="Rusak").scalar() or 0
    )
    cnt_ter = max(total - cnt_pin, 0)

    pct_ter = pct(cnt_ter, total)
    pct_pin = pct(cnt_pin, total)
    pct_rus = pct(cnt_rus, total)

    # 🔹 DATA UNTUK DIAGRAM LINGKARAN
    loan_rows = (
        db.session.query(
            Pengajuan.nama_barang.label("nama"),
            db.func.sum(Pengajuan.jumlah_unit).label("total"),
        )
        .filter(Pengajuan.status == "Dipinjam")  
        .group_by(Pengajuan.nama_barang)
        .all()
    )

    chart_labels = [row.nama for row in loan_rows]
    chart_values = [int(row.total or 0) for row in loan_rows]

    return render_template(
        "admin/index.html",
        cnt_user=cnt_user,
        cnt_pengajuan=cnt_pengajuan,
        cnt_product=cnt_product,
        cnt_ter=cnt_ter,
        cnt_pin=cnt_pin,
        cnt_rus=cnt_rus,
        total=total,
        pct_ter=pct_ter,
        pct_pin=pct_pin,
        pct_rus=pct_rus,
        # ⬇️ dikirim ke template
        chart_labels=chart_labels,
        chart_values=chart_values,
    )


def pct(n, t):
    return 0 if t == 0 else round(n * 100 / t, 2)


# ===========================
#  DAFTAR PENGAJUAN
# ===========================
@admin_bp.route("/daftar-pengajuan")
def daftarPengajuan():
    status_filter = request.args.get("status", "Semua Status")
    search_query = request.args.get("search", "").strip()  # <<< TAMBAHAN

    # Base query: hanya pengajuan yang
    # 1) belum pernah mengajukan pengembalian
    #    ATAU
    # 2) sudah mengajukan pengembalian tapi status pengembalian = Ditolak
    base_query = (
        db.session.query(Pengajuan)
        .outerjoin(Pengembalian, Pengembalian.pengajuan_id == Pengajuan.id)
        .filter(
            or_(
                Pengembalian.id.is_(None),  # belum ada pengembalian
                Pengembalian.status == "Ditolak",  # pengembalian ditolak
            )
        )
    )

    # Filter status
    if status_filter != "Semua Status":
        base_query = base_query.filter(Pengajuan.status == status_filter)

    # FILTER SEARCH 
    if search_query:
        base_query = base_query.filter(Pengajuan.nama_peminjam.ilike(f"%{search_query}%"))

    items = base_query.order_by(Pengajuan.id.desc()).all()

    return render_template(
        "DaftarPengajuan.html",
        items=items,
        status_filter=status_filter,
        search_query=search_query,  # <<< kirim ke template
    )


@admin_bp.route("/pengajuan/<int:pengajuan_id>/terima", methods=["POST"])
def terimaPengajuan(pengajuan_id):
    pengajuan = Pengajuan.query.get_or_404(pengajuan_id)
    current_status = (pengajuan.status or "").strip()

    # hanya boleh di-approve dari "Menunggu"
    if current_status == "Menunggu":
        pengajuan.status = "Dipinjam"
        db.session.commit()
        kirim_notifikasi_pengajuan(pengajuan)  # ← TAMBAH INI

    else:
        # kalau bukan Menunggu, tidak diubah supaya tidak aneh
        print("Pengajuan bukan status 'Menunggu', tidak diubah.")
    
    return redirect(url_for("admin_bp.daftarPengajuan"))

def normalize_wa_number(raw: str) -> str:
    if not raw:
        return ""

    s = raw.strip()

    # ambil digit saja (hapus spasi, -, dll)
    digits = "".join(ch for ch in s if ch.isdigit())

    # kasus:
    # 08xxxx -> 62xxxx
    if digits.startswith("0"):
        digits = "62" + digits[1:]

    # 628xxxx sudah ok
    if digits.startswith("62"):
        return "whatsapp:+" + digits

    # kalau user input 8xxxx (tanpa 0) -> anggap Indonesia
    if digits.startswith("8"):
        return "whatsapp:+62" + digits

    # fallback
    return "whatsapp:+" + digits


def send_whatsapp_message(to_number: str, body: str):
    sid = os.getenv("TWILIO_ACCOUNT_SID")
    token = os.getenv("TWILIO_AUTH_TOKEN")
    sender = os.getenv("WHATSAPP_SENDER")  # whatsapp:+14155238886
    client = Client(sid, token)
    return client.messages.create(from_=sender, to=to_number, body=body)

def kirim_notifikasi_pengajuan(pengajuan):
    if os.getenv("WHATSAPP_PROVIDER") != "ENABLED":
        print("WhatsApp notifikasi DISABLED (aman)")
        return

    pesan = f"""
Halo {pengajuan.nama_peminjam},

Pengajuan peminjaman Anda telah *DIVERIFIKASI ADMIN*.

📍 Lokasi pengambilan:
Ruang Airport Technology

⏰ Jam Operasional:
Senin – Jumat
08.00 – 16.00 WIB

Silakan datang sesuai jam operasional.
Terima kasih.
"""
    try:
        nomor = normalize_wa_number(pengajuan.no_telp)
        send_whatsapp_message(nomor, pesan)
        print("WA berhasil dikirim ke", nomor)
    except Exception as e:
        print("Gagal kirim WA:", e)


    # nanti diisi API WA

@admin_bp.route("/pengajuan/<int:pengajuan_id>/tolak", methods=["POST"])
def tolakPengajuan(pengajuan_id):
    pengajuan = Pengajuan.query.get_or_404(pengajuan_id)
    pengajuan.status = "Ditolak"
    db.session.commit()
    return redirect(url_for("admin_bp.daftarPengajuan"))


@admin_bp.route("/pengajuan/<int:pengajuan_id>/update-status", methods=["POST"])
def updateStatusPengajuan(pengajuan_id):
    status = request.form.get("status")
    pengajuan = Pengajuan.query.get_or_404(pengajuan_id)
    pengajuan.status = status
    db.session.commit()
    return redirect(url_for("admin_bp.daftarPengajuan"))


# ===========================
#  DAFTAR PENGEMBALIAN
# ===========================
@admin_bp.route("/daftar-pengembalian")
def daftarPengembalian():
    status_filter = request.args.get("status", "Semua Status")
    search_query = request.args.get("search", "").strip()

    # 🔥 QUERY SESUAI DATABASE - KOLOM YANG BENAR-BENAR ADA!
    base_query = (
        Pengembalian.query.options(
            joinedload(Pengembalian.pengajuan),
            joinedload(Pengembalian.product),
        )
        .order_by(Pengembalian.id.desc())
    )

    all_items = base_query.all()

    # 🔥 PROCESS: Buat dictionary SESUAI TEMPLATE EXISTING + AUTO UPDATE DB
    processed_items = []
    for p in all_items:
        # Ambil data dari Pengembalian (utama)
        item = {
            'id': p.id,
            'id_pegawai': getattr(p.pengajuan, 'id_pegawai', '-') if p.pengajuan else '-',
            'nama_peminjam': p.nama_peminjam or '-',
            'nama_barang': p.nama_barang or '-',
            'jumlah_unit': p.jumlah_unit or 0,
            'tanggal_mulai': p.tanggal_mulai,
            'tanggal_selesai': p.tanggal_selesai,
            'status': p.status or '',
            'aksi_status': p.aksi_status or '',
            'foto_serah_terima': p.foto_serah_terima,
            'kondisi_barang': p.kondisi_barang,
            'tanggal_kembali': p.tanggal_kembali,
            'pengajuan_id': p.pengajuan_id,
            'unit': getattr(p.pengajuan, 'unit', '-') if p.pengajuan else '-',
            'no_telp': getattr(p.pengajuan, 'no_telp', '-') if p.pengajuan else '-',
            'keperluan': getattr(p.pengajuan, 'keperluan', '-') if p.pengajuan else '-',
            'ketersediaan': '-',  # bisa dihitung atau kosong
        }

        # 🔥 HITUNG aksi_status OTOMATIS
        ada_foto = bool(item['foto_serah_terima'] and str(item['foto_serah_terima']).strip())
        ada_kondisi = bool(item['kondisi_barang'] and str(item['kondisi_barang']).strip())
        
        new_aksi_status = "Dipinjam"
        if ada_foto and ada_kondisi:
            new_aksi_status = "Dikembalikan"
        elif ada_foto or ada_kondisi:
            new_aksi_status = "Menunggu"  # ✅ INI YANG DISIMPAN
        
        item['aksi_status'] = new_aksi_status
        item['ada_foto'] = ada_foto
        item['ada_kondisi'] = ada_kondisi

        # ✅ KOREKSI: AUTO UPDATE DATABASE jika berbeda
        if p.aksi_status != new_aksi_status:
            p.aksi_status = new_aksi_status
            p.status = new_aksi_status  # Sinkron status juga
            db.session.commit()
            print(f"✅ AUTO UPDATE DB {p.id}: {new_aksi_status} | Foto:{ada_foto} | Kondisi:{ada_kondisi}")

        processed_items.append(item)

    # FILTER (sama seperti sebelumnya)
    filtered = processed_items
    if status_filter != "Semua Status":
        target = status_filter.strip().lower()
        filtered = [item for item in processed_items 
                   if item['status'].strip().lower() == target or 
                       item['aksi_status'].strip().lower() == target]

    if search_query:
        q = search_query.lower()
        filtered = [item for item in filtered 
                   if q in (item['nama_peminjam'] or "").lower() or 
                       q in (item['nama_barang'] or "").lower()]

    return render_template(
        "admin/DaftarPengembalian.html",
        items=filtered,  # ✅ DATA KEMBALI NORMAL!
        status_filter=status_filter,
        search_query=search_query,
    )


def hitung_aksi_status(p: Pengembalian) -> str:
    """
    LOGIKA BARU yang JELAS:
    - BELUM ada foto DAN kondisi → "Dipinjam" 
    - SUDAH ada foto ATAU kondisi → "Menunggu"
    - SUDAH ada foto DAN kondisi → "Dikembalikan"
    """
    ada_foto = bool(p.foto_serah_terima and str(p.foto_serah_terima).strip())
    ada_kondisi = bool(p.kondisi_barang and str(p.kondisi_barang).strip())
    
    if ada_foto and ada_kondisi:
        return "Dikembalikan"
    elif ada_foto or ada_kondisi:
        return "Menunggu"
    else:
        return "Dipinjam"


@admin_bp.route("/pengembalian/<int:pengembalian_id>/terima", methods=["POST"])
def terimaPengembalian(pengembalian_id):
    try:
        # 🔥 AMBIL DATA DARI DATABASE
        pengembalian = Pengembalian.query.get_or_404(pengembalian_id)
        pengajuan = Pengajuan.query.get(pengembalian.pengajuan_id) if pengembalian.pengajuan_id else None

        # ✅ SIMPAN KONDISI BARANG (dari form)
        kondisi_baru = (request.form.get("kondisi_barang") or "").strip()
        if kondisi_baru:
            pengembalian.kondisi_barang = kondisi_baru
        # JIKA KONDISI KOSONG, TETAP PAKAI YANG LAMA
        elif not pengembalian.kondisi_barang:
            pengembalian.kondisi_barang = "Baik"  # default

        # ✅ SIMPAN FOTO SERAH TERIMA (dari form)
        file = request.files.get("foto_serah_terima")
        if file and file.filename:
            upload_dir = os.path.join(admin_bp.static_folder, "uploads", "serah_terima")
            os.makedirs(upload_dir, exist_ok=True)

            safe_name = secure_filename(file.filename)
            filepath = os.path.join(upload_dir, safe_name)
            file.save(filepath)
            
            pengembalian.foto_serah_terima = f"uploads/serah_terima/{safe_name}"

        # 🔥 FORCE HITUNG STATUS BARU BERDASARKAN DATABASE
        ada_foto = bool(pengembalian.foto_serah_terima and str(pengembalian.foto_serah_terima).strip())
        ada_kondisi = bool(pengembalian.kondisi_barang and str(pengembalian.kondisi_barang).strip())
        
        if ada_foto and ada_kondisi:
            new_status = "Dikembalikan"
            # ✅ SET TANGGAL KEMBALI JIKA LENGKAP
            pengembalian.tanggal_kembali = date.today()
            if pengembalian.tanggal_mulai:
                pengembalian.durasi = (date.today() - pengembalian.tanggal_mulai).days
        elif ada_foto or ada_kondisi:
            new_status = "Menunggu"
        else:
            new_status = "Dipinjam"

        # ✅ SYNCHRONIZE SEMUA KOLOM DATABASE
        pengembalian.status = new_status
        pengembalian.aksi_status = new_status  # 🔥 INI YANG PENTING!
        
        # Sync ke pengajuan juga
        if pengajuan:
            pengajuan.status = new_status

        # 💾 COMMIT KE DATABASE
        db.session.commit()
        
        # 📱 FLASH MESSAGE SESUAI STATUS
        flash_messages = {
            "Dikembalikan": "✅ Pengembalian SUKSES! Foto & kondisi lengkap.",
            "Menunggu": "⏳ Menunggu kelengkapan (foto/kondisi belum lengkap).",
            "Dipinjam": "📤 Silakan upload foto & kondisi barang."
        }
        flash(flash_messages.get(new_status, "Data disimpan."), 
              "success" if new_status == "Dikembalikan" else "warning")

        print(f"✅ UPDATE {pengembalian_id}: {new_status} | Foto:{ada_foto} | Kondisi:{ada_kondisi}")

    except Exception as e:
        db.session.rollback()
        current_app.logger.exception("ERROR terimaPengembalian")
        flash(f"❌ Error: {str(e)}", "error")

    return redirect(url_for("admin_bp.daftarPengembalian"))




# ===========================
#  DAFTAR ALAT
# ===========================
@admin_bp.route("/daftar-alat")
def daftarAlat():
    # ambil nilai dari query string
    status_filter = request.args.get("status", "Semua Status")
    search_query = request.args.get("search", "").strip()

    # query dasar
    query = Product.query

    # FILTER STATUS (dropdown)
    if status_filter and status_filter != "Semua Status":
        query = query.filter(Product.status == status_filter)

    # FILTER SEARCH 
    if search_query:
        like = f"%{search_query}%"
        query = query.filter(
            or_(
                Product.product_name.ilike(like),
                Product.product_id.ilike(like),
            )
        )

    # ambil data alat yang sudah terfilter
    items = query.order_by(Product.product_id.asc()).all()

    # statistik (boleh tetap semua data, tidak terfilter)
    total = db.session.query(db.func.sum(Product.quantity)).scalar() or 0
    cnt_pin = (
        db.session.query(db.func.sum(Pengajuan.jumlah_unit))
        .filter(Pengajuan.status == "Dipinjam")
        .scalar()
        or 0
    )
    cnt_rus = (
        db.session.query(db.func.sum(Product.quantity)).filter_by(status="Rusak").scalar() or 0
    )
    cnt_ter = max(total - cnt_pin, 0)

    return render_template(
        "admin/DaftarAlat.html",
        items=items,
        cnt_ter=cnt_ter,
        cnt_pin=cnt_pin,
        cnt_rus=cnt_rus,
        total=total,
        status_filter=status_filter,  # ⬅️ penting untuk template
        search_query=search_query,  # ⬅️ penting untuk template
    )


@admin_bp.route("/tambah-alat", methods=["POST"])
def tambahAlat():
    name = request.form.get("p_name", "").strip()
    desc = request.form.get("p_desc", "").strip()
    qty = request.form.get("p_qty", type=int)
    status = request.form.get("status", "Tersedia")

    upload_dir = os.path.join(admin_bp.static_folder, "uploads")
    os.makedirs(upload_dir, exist_ok=True)

    file = request.files.get("file")
    filename = None
    if file and file.filename:
        safe_name = secure_filename(file.filename)
        filepath = os.path.join(upload_dir, safe_name)
        file.save(filepath)
        filename = safe_name

    new_id = generate_product_id()

    product = Product(
        product_id=new_id,
        product_name=name,
        product_desc=desc,
        product_image=filename,
        quantity=qty,
        status=status,
    )
    db.session.add(product)
    db.session.flush()

    gallery_files = request.files.getlist("gallery_files")
    for idx, gfile in enumerate(gallery_files[:4]):
        if gfile and gfile.filename:
            g_safe = secure_filename(gfile.filename)
            g_path = os.path.join(upload_dir, g_safe)
            gfile.save(g_path)

            pg = ProductGallery(product_id=new_id, image_path=g_safe, sort_order=idx)
            db.session.add(pg)

    db.session.commit()
    return redirect(url_for("admin_bp.daftarAlat"))


@admin_bp.route("/produk/<string:product_id>/delete", methods=["POST"])
def deleteProduct(product_id):
    product = Product.query.get_or_404(product_id)

    for g in list(product.gallery):
        db.session.delete(g)

    for k in list(product.pengembalian_list):
        db.session.delete(k)

    db.session.delete(product)
    db.session.commit()

    return redirect(url_for("admin_bp.daftarAlat"))


def generate_product_id():
    last_product = Product.query.order_by(Product.product_id.desc()).first()
    if not last_product or not last_product.product_id:
        return "A001"

    last_id = last_product.product_id
    try:
        last_num = int(last_id[1:])
    except ValueError:
        last_num = 0

    new_num = last_num + 1
    return f"A{new_num:03d}"


@admin_bp.route("/produk/<string:product_id>/status", methods=["POST"])
def updateStatusProduct(product_id):
    status = request.form.get("status")
    product = Product.query.get_or_404(product_id)
    product.status = status
    db.session.commit()
    return redirect(url_for("admin_bp.daftarAlat"))


@admin_bp.route("/detail-alat/<string:product_id>")
def detailAlat(product_id):
    item = Product.query.get_or_404(product_id)
    gallery = (
        ProductGallery.query.filter_by(product_id=product_id)
        .order_by(ProductGallery.sort_order)
        .all()
    )
    return render_template("DetailAlat.html", item=item, gallery=gallery)


@admin_bp.route("/detail-alat/<string:product_id>/update", methods=["POST"])
def update_detail_alat(product_id):
    product = Product.query.get_or_404(product_id)

    product_name = request.form.get("product_name", "").strip()
    product_desc = request.form.get("product_desc", "").strip()
    status = request.form.get("status", "").strip()
    quantity = request.form.get("quantity", type=int)

    if product_name:
        product.product_name = product_name

    product.product_desc = product_desc

    if status:
        product.status = status

    if quantity is not None:
        product.quantity = quantity

    db.session.commit()
    return redirect(url_for("admin_bp.detailAlat", product_id=product_id))


@admin_bp.route("/detail-alat/<string:product_id>/upload-gallery", methods=["POST"])
def upload_gallery(product_id):
    product = Product.query.get_or_404(product_id)

    gallery_files = request.files.getlist("detail_photos")
    upload_dir = os.path.join(admin_bp.static_folder, "uploads")
    os.makedirs(upload_dir, exist_ok=True)

    last = (
        ProductGallery.query.filter_by(product_id=product_id)
        .order_by(ProductGallery.sort_order.desc())
        .first()
    )
    start_order = (last.sort_order + 1) if last else 0

    for i, f in enumerate(gallery_files[:4]):
        if f and f.filename:
            safe_name = secure_filename(f.filename)
            filepath = os.path.join(upload_dir, safe_name)
            f.save(filepath)

            pg = ProductGallery(
                product_id=product_id,
                image_path=safe_name,
                sort_order=start_order + i,
            )
            db.session.add(pg)

    db.session.commit()
    return redirect(url_for("admin_bp.detailAlat", product_id=product_id))


@admin_bp.route("/manajemen-user")
def manajemenUser():
    status_filter = request.args.get("status", "Semua Status")
    search_query = request.args.get("search", "").strip()

    # query dasar
    query = Pegawai.query

    # FILTER STATUS
    if status_filter and status_filter != "Semua Status":
        query = query.filter(Pegawai.status == status_filter)

    # FILTER SEARCH 
    if search_query:
        like = f"%{search_query}%"
        query = query.filter(
            or_(
                Pegawai.nama_pegawai.ilike(like),
                Pegawai.id_pegawai.ilike(like),
                Pegawai.email.ilike(like),
                Pegawai.unit.ilike(like),
                Pegawai.username.ilike(like),
            )
        )

    items = query.order_by(Pegawai.id.asc()).all()

    return render_template(
        "admin/ManajemenUser.html",
        items=items,
        status_filter=status_filter,
        search_query=search_query,
    )

def generate_unique_id_pegawai():
    last_pegawai = Pegawai.query.order_by(Pegawai.id_pegawai.desc()).first()
    if not last_pegawai or not last_pegawai.id_pegawai:
        return "PG001"
    
    last_id = last_pegawai.id_pegawai
    last_number = int(last_id[2:])  # Ambil angka dari ID, misal PG001 -> 1
    new_id = f"PG{last_number + 1:03d}"
    return new_id



@admin_bp.route("/pegawai/add", methods=["POST"])
def addPegawai():
    nama_pegawai = request.form.get("nama_pegawai", "").strip()
    email = request.form.get("email", "").strip()
    unit = request.form.get("unit", "").strip()
    status = request.form.get("status", "Aktif")
    username = request.form.get("username")
    password = request.form.get("password", "1234")  
    no_telp = request.form.get("no_telp")

    # Generate id_pegawai baru yang unik
    id_pegawai = generate_unique_id_pegawai()

    # Foto profil (jika ada)
    profile_photo_path = None
    file = request.files.get("profile_photo")
    if file and file.filename:
        upload_dir = os.path.join(admin_bp.static_folder, "uploads")
        os.makedirs(upload_dir, exist_ok=True)

        safe_name = secure_filename(file.filename)
        filepath = os.path.join(upload_dir, safe_name)
        file.save(filepath)

        profile_photo_path = f"uploads/{safe_name}"

    # Membuat objek Pegawai untuk disimpan ke dalam database
    pegawai = Pegawai(
        id_pegawai=id_pegawai,
        nama_pegawai=nama_pegawai,
        email=email,
        unit=unit,
        status=status,
        username=username,
        password=generate_password_hash(password),  # Menggunakan hash untuk menyimpan password
        profile_photo=profile_photo_path,
        no_telp=no_telp,
    )

    # Menambahkan pegawai ke dalam session dan commit
    db.session.add(pegawai)
    try:
        db.session.commit()  # Coba simpan ke database
        flash("Pegawai berhasil ditambahkan.", "success")
    except Exception as e:
        db.session.rollback()  # Jika error, rollback transaksi
        flash(f"Terjadi kesalahan: {str(e)}", "error")

    return redirect(url_for("admin_bp.manajemenUser"))


@admin_bp.route("/pegawai/<int:pegawai_id>/update", methods=["POST"])
def updatePegawai(pegawai_id):
    pegawai = Pegawai.query.get_or_404(pegawai_id)

    pegawai.nama_pegawai = request.form.get("nama_pegawai", pegawai.nama_pegawai)
    pegawai.id_pegawai = request.form.get("id_pegawai", pegawai.id_pegawai)
    pegawai.email = request.form.get("email", pegawai.email)
    pegawai.unit = request.form.get("unit", pegawai.unit)
    pegawai.status = request.form.get("status", pegawai.status)

    pegawai.no_telp = request.form.get("no_telp", pegawai.no_telp)

    username = request.form.get("username")
    password = request.form.get("password")

    if username:
        pegawai.username = username
    else:
        pegawai.username = (pegawai.nama_pegawai or "").replace(" ", "").lower()

    if password:
        pegawai.password = password

    file = request.files.get("profile_photo")
    if file and file.filename:
        upload_dir = os.path.join(admin_bp.static_folder, "uploads")
        os.makedirs(upload_dir, exist_ok=True)

        safe_name = secure_filename(file.filename)
        filepath = os.path.join(upload_dir, safe_name)
        file.save(filepath)

        pegawai.profile_photo = f"uploads/{safe_name}"

    db.session.commit()
    return redirect(url_for("admin_bp.manajemenUser"))


@admin_bp.route("/pegawai/<int:pegawai_id>/delete", methods=["POST"])
def deletePegawai(pegawai_id):
    pegawai = Pegawai.query.get_or_404(pegawai_id)

    if pegawai.profile_photo:
        profile_path = pegawai.profile_photo.lstrip("/")
        static_folder_rel = admin_bp.static_folder or ""
        static_folder_abs = os.path.normpath(
            os.path.join(current_app.root_path, static_folder_rel)
        )
        file_path = os.path.join(static_folder_abs, profile_path)

        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass

    db.session.delete(pegawai)
    db.session.commit()

    return redirect(url_for("admin_bp.manajemenUser"))


@admin_bp.route("/manajemen-admin")
def manajemenAdmin():
    # hanya boleh diakses super admin
    if session.get("admin_role") != "super_admin":
        return redirect(url_for("admin_bp.home_admin"))

    status_filter = request.args.get("status", "Semua Status")
    search_query = request.args.get("search", "").strip()

    # hanya ambil akun dengan role = 'admin'
    query = Pegawai.query.filter(Pegawai.role == "admin")

    if status_filter and status_filter != "Semua Status":
        query = query.filter(Pegawai.status == status_filter)

    if search_query:
        like = f"%{search_query}%"
        query = query.filter(
            or_(
                Pegawai.nama_pegawai.ilike(like),
                Pegawai.id_pegawai.ilike(like),
                Pegawai.email.ilike(like),
                Pegawai.unit.ilike(like),
                Pegawai.username.ilike(like),
            )
        )

    items = query.order_by(Pegawai.id.asc()).all()

    return render_template(
        "admin/ManajemenAdmin.html",
        items=items,
        status_filter=status_filter,
        search_query=search_query,
    )

@admin_bp.route("/laporan-peminjaman", methods=["GET"])
def LaporanPeminjaman():
    status_filter = request.args.get("status", "Semua Status")
    search_query = (request.args.get("search") or "").strip()

    query = (
        db.session.query(
            Pengajuan.id,
            Pengajuan.nama_peminjam,
            Pengajuan.nama_barang,
            Pengajuan.jumlah_unit,
            Pengajuan.tanggal_mulai,
            Pengajuan.tanggal_selesai,
            Pengajuan.status.label("status_pengajuan"),

            # ✅ ambil juga aksi_status + status pengembalian
            Pengembalian.aksi_status.label("aksi_status"),
            Pengembalian.status.label("status_pengembalian"),

            # ✅ kalau yang kamu mau tampil "tanggal kembali real"
            Pengembalian.tanggal_kembali.label("tanggal_kembali_real"),

            # kalau mau tetap pakai yang sudah ada:
            Pengembalian.tanggal_selesai.label("tanggal_dikembalikan"),
        )
        .join(Pengembalian, Pengembalian.pengajuan_id == Pengajuan.id, isouter=True)
    )

    # ✅ FILTER STATUS: cek pengajuan.status ATAU pengembalian.aksi_status ATAU pengembalian.status
    if status_filter != "Semua Status":
        query = query.filter(
            or_(
                Pengajuan.status == status_filter,
                Pengembalian.aksi_status == status_filter,
                Pengembalian.status == status_filter,
            )
        )

    # ✅ SEARCH
    if search_query:
        query = query.filter(Pengajuan.nama_peminjam.ilike(f"%{search_query}%"))

    items = query.order_by(Pengajuan.id.desc()).all()

    return render_template(
        "LaporanPeminjaman.html",
        items=items,
        status_filter=status_filter,
        search_query=search_query,
    )

@admin_bp.route("/laporan-peminjaman/pdf", methods=["GET"])
def export_laporan_peminjaman_pdf():
    status_filter = request.args.get("status", "Semua Status")
    search_query = (request.args.get("search") or "").strip()

    # Query sama seperti LaporanPeminjaman()
    query = (
        db.session.query(
            Pengajuan.id,
            Pengajuan.nama_peminjam,
            Pengajuan.nama_barang,
            Pengajuan.jumlah_unit,
            Pengajuan.tanggal_mulai,
            Pengajuan.tanggal_selesai,
            Pengajuan.status.label("status_pengajuan"),
            Pengembalian.aksi_status.label("aksi_status"),
            Pengembalian.status.label("status_pengembalian"),
            Pengembalian.tanggal_kembali.label("tanggal_kembali_real"),
            Pengembalian.tanggal_selesai.label("tanggal_dikembalikan"),
        )
        .join(Pengembalian, Pengembalian.pengajuan_id == Pengajuan.id, isouter=True)
    )

    if status_filter != "Semua Status":
        query = query.filter(
            or_(
                Pengajuan.status == status_filter,
                Pengembalian.aksi_status == status_filter,
                Pengembalian.status == status_filter,
            )
        )

    if search_query:
        query = query.filter(Pengajuan.nama_peminjam.ilike(f"%{search_query}%"))

    items = query.order_by(Pengajuan.id.desc()).all()

    # ==== BUAT PDF ====
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(A4), leftMargin=18, rightMargin=18, topMargin=18, bottomMargin=18)

    styles = getSampleStyleSheet()
    story = []

    title = Paragraph("Laporan Peminjaman", styles["Title"])
    story.append(title)
    story.append(Spacer(1, 10))

    info = Paragraph(
        f"Filter Status: <b>{status_filter}</b> &nbsp;&nbsp; | &nbsp;&nbsp; Search: <b>{search_query or '-'}</b>",
        styles["Normal"],
    )
    story.append(info)
    story.append(Spacer(1, 12))

    # Header tabel PDF
    data = [[
        "ID Transaksi",
        "Nama Peminjam",
        "Nama Barang",
        "Jumlah",
        "Tanggal Pinjam",
        "Tanggal Kembali",
        "Status",
    ]]

    # Isi tabel PDF
    for p in items:
        # tanggal kembali prioritas: tanggal_kembali_real -> tanggal_dikembalikan -> tanggal_selesai
        tgl_kembali = p.tanggal_kembali_real or p.tanggal_dikembalikan or p.tanggal_selesai or "-"

        # status prioritas: aksi_status -> status_pengembalian -> status_pengajuan
        st = p.aksi_status or p.status_pengembalian or p.status_pengajuan or "-"

        data.append([
            str(p.id),
            str(p.nama_peminjam or "-"),
            str(p.nama_barang or "-"),
            str(p.jumlah_unit or 0),
            str(p.tanggal_mulai or "-"),
            str(tgl_kembali),
            str(st),
        ])

    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.whitesmoke]),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))

    story.append(table)
    doc.build(story)

    buffer.seek(0)
    filename = "Laporan_Peminjaman.pdf"

    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype="application/pdf",
    )

