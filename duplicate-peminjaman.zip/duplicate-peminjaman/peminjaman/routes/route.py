# routes/route.py
import os
from datetime import datetime

from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from pandas import options
from sqlalchemy import desc
from sqlalchemy.orm import joinedload

from extensions import db
from models import Pengajuan, Pengembalian, Pegawai, Product, ProductGallery


main = Blueprint("main", __name__)



@main.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        # Periksa apakah username dan password cocok dengan data di database
        user = Pegawai.query.filter_by(username=username, password=password).first()

        if user:
            session["user_id"] = user.id
            session["username"] = user.username
            session["id_pegawai"] = user.id_pegawai
            session["profile_photo"] = user.profile_photo
            session["email"] = user.email
            session["unit"] = user.unit
            session["no_telp"] = user.no_telp

            flash("Login berhasil", "success")
            return redirect(url_for("main.home"))

        flash("Username atau password salah", "danger")

    return render_template("user/Login.html")


@main.route("/")
def home():
    if "user_id" not in session:
        return redirect(url_for("main.login"))

    # --- DATA REKOMENDASI ---
    rekomendasi = (
        Product.query.order_by(Product.uploaded_date.desc()).limit(4).all()
    )

    return render_template(
        "user/index.html",
        rekomendasi=rekomendasi,
    )


# ====== Daftar Peralatan ======
@main.route("/daftar-alat")
def daftarAlat():
    items = Product.query.order_by(Product.product_id.asc()).all()

    total = db.session.query(db.func.sum(Product.quantity)).scalar() or 0

    cnt_pin = (
        db.session.query(db.func.sum(Pengajuan.jumlah_unit))
        .filter(Pengajuan.status == "Dipinjam")
        .scalar()
        or 0
    )

    cnt_rus = (
        db.session.query(db.func.sum(Product.quantity))
        .filter(Product.status == "Rusak")
        .scalar()
        or 0
    )

    cnt_ter = max(total - cnt_pin, 0)

    return render_template(
        "user/DaftarAlat.html",
        items=items,
        cnt_ter=cnt_ter,
        cnt_pin=cnt_pin,
        cnt_rus=cnt_rus,
        total=total,
    )


def generate_product_id():
    last_product = Product.query.order_by(Product.product_id.desc()).first()
    if not last_product:
        return "A001"

    last_id = last_product.product_id
    try:
        last_num = int(last_id[1:])
    except ValueError:
        last_num = 0

    new_num = last_num + 1
    return f"A{new_num:03d}"


# ====== Detail Peralatan (pakai product_id) ======
@main.route("/detail-alat/<string:product_id>")
def detailAlat(product_id):
    # data barang utama
    item = Product.query.get_or_404(product_id)

    # ambil foto-foto detail dari tabel product_gallery
    gallery = (
        ProductGallery.query.filter_by(product_id=product_id)
        .order_by(ProductGallery.sort_order.asc())
        .all()
    )

    # kirim juga gallery ke template
    return render_template("user/DetailAlat.html", item=item, gallery=gallery)


@main.get("/api/products/search")
def api_search_products():
    q = (request.args.get("q") or "").strip()
    only_available = request.args.get("available", "1") != "0"

    query = Product.query
    if q:
        like = f"%{q}%"
        query = query.filter(Product.product_name.ilike(like))
    if only_available:
        query = query.filter(Product.status.ilike("Tersedia"))

    items = query.order_by(Product.product_name.asc()).limit(10).all()
    return jsonify(
        [
            {
                "product_id": p.product_id,
                "product_name": p.product_name,
                "status": p.status,
                "quantity": p.quantity,
            }
            for p in items
        ]
    )


# ---------- PENGEMBALIAN ----------
@main.route("/pengembalian", methods=["GET", "POST"])
def pengembalian():
    # wajib login
    if "user_id" not in session:
        flash("Silakan login terlebih dahulu.", "error")
        return redirect(url_for("main.login"))

    # ============== POST: SIMPAN FORM PENGEMBALIAN ==============
    if request.method == "POST":
        try:
            # --- ambil & validasi ID pengajuan ---
            id_pengajuan = request.form.get("id_pengajuan", type=int)
            if not id_pengajuan:
                flash("ID pengajuan tidak ditemukan.", "error")
                return redirect(url_for("main.pengembalian"))

            pengajuan = Pengajuan.query.get(id_pengajuan)
            if pengajuan is None:
                flash("Data pengajuan tidak valid.", "error")
                return redirect(url_for("main.pengembalian"))

            # kalau sudah pernah mengajukan pengembalian, blok
            if pengajuan.pengembalian:
                flash("Pengajuan ini sudah memiliki data pengembalian.", "error")
                return redirect(url_for("main.pengembalian"))

            # --- ambil data form ---
            tgl_kembali_raw = request.form.get("tanggal_kembali")
            if not tgl_kembali_raw:
                flash("Tanggal kembali wajib diisi.", "error")
                return redirect(url_for("main.pengembalian"))

            # tanggal kembali yang DIAJUKAN peminjam
            tanggal_kembali = datetime.strptime(tgl_kembali_raw, "%Y-%m-%d").date()

            # catatan kondisi barang dari user (nanti diverifikasi admin)
            kondisi_barang_user = (request.form.get("kondisi_barang") or "").strip()

            # --- simpan ke tabel Pengembalian ---
            row = Pengembalian(
                pengajuan_id=pengajuan.id,
                product_id=pengajuan.product_id,
                nama_peminjam=pengajuan.nama_peminjam,
                id_pegawai=pengajuan.id_pegawai,
                unit=pengajuan.unit,
                no_telp=pengajuan.no_telp,
                nama_barang=pengajuan.nama_barang,
                kategori_barang=pengajuan.kategori_barang,
                jumlah_unit=pengajuan.jumlah_unit,
                ketersediaan=pengajuan.ketersediaan,
                keperluan=pengajuan.keperluan,
                tanggal_mulai=pengajuan.tanggal_mulai,
                # tanggal kembali yang diinput user di form
                tanggal_selesai=tanggal_kembali,
                # tanggal_kembali (kolom baru) sengaja dikosongkan dulu
                # akan diisi admin saat klik TERIMA
                kondisi_barang=kondisi_barang_user,
                foto_serah_terima=None,
                status="Dipinjam",  # menunggu verifikasi admin
            )

            db.session.add(row)
            db.session.commit()

            # ⬇ popup sukses di template cuma muncul kalau baris ini terpanggil
            flash(
                "Data pengembalian berhasil dikirim, menunggu verifikasi admin.",
                "pengembalian_success",
            )
            return redirect(url_for("main.pengembalian"))

        except Exception:
            current_app.logger.exception("DB Error (pengembalian)")
            db.session.rollback()
            flash("Terjadi kesalahan saat menyimpan data.", "error")
            return redirect(url_for("main.pengembalian"))

    # ============== GET: TAMPILKAN DAFTAR YANG BISA DIKEMBALIKAN ==============
    items = (
        Pengajuan.query.outerjoin(Pengembalian, Pengembalian.pengajuan_id == Pengajuan.id)
        .filter(
            Pengajuan.id_pegawai == session["id_pegawai"],
            Pengembalian.id.is_(None),  # hanya yang BELUM punya pengembalian
        )
        .order_by(Pengajuan.id.desc())
        .all()
    )

    return render_template("user/Pengembalian.html", items=items)


# ---------- PEMINJAMAN ----------
@main.route("/peminjaman", methods=["GET", "POST"])
def peminjaman():
    if request.method == "POST":
        try:
            nama_peminjam = request.form.get("nama", "").strip()
            id_pegawai = request.form.get("id_pegawai", "").strip()
            unit = request.form.get("unit", "").strip()
            no_telp = request.form.get("no_telp", "").strip()
            product_id = (request.form.get("product_id") or "").strip()
            nama_barang = request.form.get("nama_barang", "").strip()
            kategori_barang = request.form.get("kategori", "").strip()
            jumlah_unit = int(request.form.get("jumlah_unit", 0))
            ketersediaan = int(request.form.get("ketersediaan", 0))
            keperluan = request.form.get("keperluan", "").strip()
            tanggal_mulai = datetime.strptime(request.form.get("tgl_mulai"), "%Y-%m-%d").date()
            tanggal_selesai = datetime.strptime(request.form.get("tgl_selesai"), "%Y-%m-%d").date()

            row = Pengajuan(
                nama_peminjam=nama_peminjam,
                id_pegawai=id_pegawai,
                unit=unit,
                no_telp=no_telp,
                product_id=product_id,
                nama_barang=nama_barang,
                kategori_barang=kategori_barang,
                jumlah_unit=jumlah_unit,
                ketersediaan=ketersediaan,
                keperluan=keperluan,
                tanggal_mulai=tanggal_mulai,
                tanggal_selesai=tanggal_selesai,
            )
            db.session.add(row)
            db.session.commit()

            flash("Pengajuan berhasil disimpan.", "peminjaman_success")
            return redirect(url_for("main.peminjaman"))

        except Exception as e:
            db.session.rollback()
            print("DB Error (peminjaman):", e)
            flash("Terjadi kesalahan saat menyimpan data.", "error")

    return render_template("user/PeminjamanAlat.html")


@main.route("/contact")
def contact():
    return render_template("user/contact.html")


@main.route("/profile")
def profile():
    if "user_id" not in session:
        return redirect(url_for("main.login"))

    user = Pegawai.query.get(session["user_id"])

    if not user:
        flash("Pengguna tidak ditemukan.", "error")
        return redirect(url_for("main.login"))

    return render_template("user/Profile.html", user=user)


from sqlalchemy.orm import contains_eager

@main.route("/riwayat-peminjaman")
def riwayatPeminjaman():
    if "user_id" not in session:
        return redirect(url_for("main.login"))

    rows = (
        db.session.query(Pengajuan)
        .outerjoin(Pengembalian, Pengembalian.pengajuan_id == Pengajuan.id)
        .options(
            contains_eager(Pengajuan.pengembalian),
            joinedload(Pengajuan.product),
        )
        .filter(Pengajuan.id_pegawai == session["id_pegawai"])
        .order_by(Pengajuan.id.desc())
        .all()
    )

    return render_template("user/RiwayatPeminjaman.html", items=rows)


@main.route("/logout")
def logout():
    session.clear()
    flash("Anda telah logout", "info")
    return redirect(url_for("main.login"))
