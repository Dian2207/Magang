document.addEventListener('DOMContentLoaded', () => {
  const panel   = document.getElementById('detailPanel');
  const closeEl = document.getElementById('closeDetail');

  if (!panel || !closeEl) return;

  const refreshUrl = panel.dataset.refreshUrl || window.location.href;

  const setText = (selector, value) => {
    const el = panel.querySelector(selector);
    if (el) el.textContent = (value ?? '-') || '-';
  };

  // tombol (pengajuan) + form (pengembalian)
  const btnTerima = panel.querySelector('.btn-terima');
  const btnTolak  = panel.querySelector('.btn-tolak');
  const formTerimaPengembalian = document.getElementById('formTerimaPengembalian');

  // elemen khusus pengembalian
  const imgPreview    = panel.querySelector('.d-foto-serah-terima');
  const selectKondisi = panel.querySelector('select[name="kondisi_barang"]');
  const fileInput     = panel.querySelector('input[name="foto_serah_terima"]');
  const uploadWrapper = panel.querySelector('.upload-wrapper');
  const row2Col        = panel.querySelector('.detail-row-2col');   // kotak foto+kondisi
  const detailButtons  = panel.querySelector('.detail-buttons');    // tempat tombol

  let currentUrlTerima = null;
  let currentUrlTolak  = null;
  let currentStatus    = null;

  const isFinalStatusPengembalian = (st) => {
  const s = (st || '').trim().toLowerCase();
  return s === 'dikembalikan' || s === 'overdate';
};


  const setPengembalianReadonlyUI = (isFinal) => {
    // kalau final: hide tombol submit, disable input, tampilkan hanya isi data
    if (detailButtons) detailButtons.style.display = isFinal ? 'none' : '';
    if (uploadWrapper) uploadWrapper.style.display = isFinal ? 'none' : '';
    if (fileInput) fileInput.disabled = !!isFinal;
    if (selectKondisi) selectKondisi.disabled = !!isFinal;

    // kalau kamu ingin kotak 2 kolom tetap tampil tapi read-only:
    // biarkan row2Col tampil, tapi tanpa upload + tanpa tombol (sudah di-handle di atas)
    // kalau kamu ingin seluruh row2Col hilang saat final, uncomment baris ini:
    // if (row2Col) row2Col.style.display = isFinal ? 'none' : '';
  };

  // ============ BUKA PANEL ============
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn-detail');
    if (!btn) return;

    currentUrlTerima = btn.dataset.urlTerima || btn.getAttribute('data-url-terima') || null;
    currentUrlTolak  = btn.dataset.urlTolak  || btn.getAttribute('data-url-tolak')  || null;
    currentStatus    = ((btn.dataset.status || '').trim()) || 'Menunggu';



    // isi detail umum (dipakai dua halaman)
    setText('.d-nama',         btn.dataset.nama);
    setText('.d-idpegawai',    btn.dataset.idpegawai);
    setText('.d-unit',         btn.dataset.unit);
    setText('.d-notelp',       btn.dataset.notelp);
    setText('.d-barang',       btn.dataset.barang);
    setText('.d-kategori',     btn.dataset.kategori);
    setText('.d-jumlah',       btn.dataset.jumlah);
    setText('.d-ketersediaan', btn.dataset.ketersediaan);
    setText('.d-keperluan',    btn.dataset.keperluan);
    setText('.d-mulai',        btn.dataset.mulai);
    setText('.d-selesai',      btn.dataset.selesai);

    // ====== MODE PENGEMBALIAN ======
    if (formTerimaPengembalian) {
      if (currentUrlTerima) formTerimaPengembalian.action = currentUrlTerima;

      // set kondisi dari DB
      if (selectKondisi) {
        selectKondisi.value = btn.dataset.kondisi || 'Baik';
      }

      // preview foto dari DB (kalau ada)
      if (imgPreview) {
        const fotoUrl = btn.dataset.fotoUrl || '';
        if (fotoUrl) {
          imgPreview.src = fotoUrl;
          imgPreview.style.display = 'block';
        } else {
          imgPreview.src = '';
          imgPreview.style.display = 'none';
        }
      }

      // kunci UI kalau status sudah final
      const final = isFinalStatusPengembalian(currentStatus);
      setPengembalianReadonlyUI(final);

// ✅ PAKSA: kalau final, tombol TERIMA harus hilang
if (final) {
  if (detailButtons) detailButtons.style.display = 'none';
}


      // reset tombol submit kalau sebelumnya pernah disable
      if (!final) {
        const submitBtn = detailButtons?.querySelector('.btn-terima');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Terima';
        }
      }
    }

    // ====== MODE PENGAJUAN ======
    if (!formTerimaPengembalian) {
      const isMenunggu = (currentStatus === 'Menunggu');
      if (btnTerima) btnTerima.style.display = (isMenunggu && currentUrlTerima) ? 'inline-block' : 'none';
      if (btnTolak)  btnTolak.style.display  = (isMenunggu && currentUrlTolak)  ? 'inline-block' : 'none';
    }

    panel.classList.add('active');
  });

  // ============ TUTUP PANEL ============
  closeEl.addEventListener('click', () => panel.classList.remove('active'));
  window.addEventListener('click', (e) => {
    if (e.target === panel) panel.classList.remove('active');
  });

  // ============ AKSI UNTUK PENGAJUAN SAJA ============
  if (!formTerimaPengembalian) {
    if (btnTerima) {
      btnTerima.addEventListener('click', async () => {
        if (!currentUrlTerima || currentStatus !== 'Menunggu') return;
        try {
          const resp = await fetch(currentUrlTerima, { method: 'POST' });
          console.log('Terima Pengajuan ->', resp.status);
          window.location.href = refreshUrl;
        } catch (err) {
          console.error('Gagal terima pengajuan', err);
        }
      });
    }

    if (btnTolak) {
      btnTolak.addEventListener('click', async () => {
        if (!currentUrlTolak || currentStatus !== 'Menunggu') return;
        try {
          const resp = await fetch(currentUrlTolak, { method: 'POST' });
          console.log('Tolak Pengajuan ->', resp.status);
          window.location.href = refreshUrl;
        } catch (err) {
          console.error('Gagal tolak pengajuan', err);
        }
      });
    }
  }

if (formTerimaPengembalian) {
  formTerimaPengembalian.addEventListener('submit', () => {
    // langsung sembunyikan tombol agar user nggak klik berkali-kali
    if (detailButtons) detailButtons.style.display = 'none';
    if (uploadWrapper) uploadWrapper.style.display = 'none';
    if (fileInput) fileInput.disabled = true;
    if (selectKondisi) selectKondisi.disabled = true;
  });
}

});