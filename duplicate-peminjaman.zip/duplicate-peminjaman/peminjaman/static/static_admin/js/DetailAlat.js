document.addEventListener('DOMContentLoaded', () => {
  const infoCard   = document.querySelector('.info-card');
  const editBtn    = document.querySelector('.edit-btn');
  const cancelBtn  = document.querySelector('.btn.cancel');
  const saveBtn    = document.querySelector('.btn.save');
  const detailForm = document.getElementById('detail-form');
  const inputs     = infoCard ? infoCard.querySelectorAll('input, textarea') : [];

  const thumbnailRow = document.querySelector('.thumbnail-row');
  const uploadInput  = document.getElementById('upload-photo');
  const addPhotoBtn  = document.querySelector('.add-photo-btn');
  const leftArrow    = document.querySelector('.arrow.left');
  const rightArrow   = document.querySelector('.arrow.right');

  const thumbnailForm = document.querySelector('.thumbnail-form');

  let originalValues = {};

  // ================== MODE EDIT ==================
  if (editBtn && infoCard) {
    editBtn.addEventListener('click', () => {
      infoCard.classList.add('editing');
      inputs.forEach((input, index) => {
        originalValues[index] = input.value;
        input.removeAttribute('readonly');
        input.style.background = "#fff";
        input.style.border = "1px solid #00AEEF";
      });
    });
  }

  if (cancelBtn && infoCard) {
    cancelBtn.addEventListener('click', () => {
      inputs.forEach((input, index) => {
        input.value = originalValues[index];
        input.setAttribute('readonly', true);
        input.style.background = "#f0f0f0";
        input.style.border = "1px solid #aaa";
      });
      infoCard.classList.remove('editing');
    });
  }

  // ========== SIMPAN PERUBAHAN (KIRIM KE SERVER) ==========
  if (saveBtn && infoCard && detailForm) {
    saveBtn.addEventListener('click', () => {
      if (!infoCard.classList.contains('editing')) {
        alert('Klik tombol "Edit" terlebih dahulu.');
        return;
      }

      const confirmSave = confirm('Apakah Anda yakin ingin menyimpan perubahan ini?');
      if (confirmSave) {
        detailForm.submit();
      }
    });
  }

  // ================== TAMBAH FOTO GALERI ==================
  if (addPhotoBtn && uploadInput && thumbnailRow && infoCard) {
    addPhotoBtn.addEventListener('click', () => {
      if (infoCard.classList.contains('editing')) {
        uploadInput.click();
      } else {
        alert('Klik tombol "Edit" dulu untuk menambahkan foto.');
      }
    });

    uploadInput.addEventListener('change', (event) => {
      const files = event.target.files;
      if (!files || files.length === 0) return;

      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = function (e) {
          const newImg = document.createElement('img');
          newImg.src = e.target.result;
          newImg.alt = "Foto baru";
          thumbnailRow.insertBefore(newImg, addPhotoBtn);
        };
        reader.readAsDataURL(file);
      });

      if (thumbnailForm && infoCard.classList.contains('editing')) {
        thumbnailForm.submit();
      }
    });
  }

  // ================== SCROLL ARROW (kalau dipakai) ==================
  if (leftArrow && thumbnailRow) {
    leftArrow.addEventListener('click', () => {
      thumbnailRow.scrollBy({ left: -200, behavior: 'smooth' });
    });
  }

  if (rightArrow && thumbnailRow) {
    rightArrow.addEventListener('click', () => {
      thumbnailRow.scrollBy({ left: 200, behavior: 'smooth' });
    });
  }
});
