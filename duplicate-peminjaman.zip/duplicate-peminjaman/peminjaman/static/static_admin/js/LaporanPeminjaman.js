// static_admin/js/LaporanPeminjaman.js

document.addEventListener('DOMContentLoaded', () => {
  const statusFilter = document.getElementById('statusFilter');
  const searchInput  = document.getElementById('searchInput');

  if (!statusFilter || !searchInput) {
    return;
  }

  function applyFilter() {
    const params = new URLSearchParams(window.location.search);

    // status dari dropdown
    const st = statusFilter.value || 'Semua Status';
    params.set('status', st);

    // keyword dari input search
    const s = searchInput.value.trim();
    if (s !== '') {
      params.set('search', s);
    } else {
      params.delete('search');
    }

    const baseUrl = window.location.pathname; // /laporan-peminjaman
    window.location.href = baseUrl + '?' + params.toString();
  }

  // Ganti status -> langsung filter
  statusFilter.addEventListener('change', applyFilter);

  // Ketik nama -> auto filter setelah jeda 400ms
  let timer = null;
  searchInput.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(applyFilter, 400);
  });
});
