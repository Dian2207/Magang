// ========== MODAL TAMBAH ALAT ==========
const addToolBtn = document.querySelector('.btn-add-tool');
const modal      = document.getElementById('modalTambahAlat');
const closeBtn   = document.querySelector('.close-modal');

if (addToolBtn && modal) {
  addToolBtn.addEventListener('click', () => {
    modal.style.display = 'block';
  });
}

if (closeBtn && modal) {
  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });
}

window.addEventListener('click', (e) => {
  if (e.target === modal) {
    modal.style.display = 'none';
  }
});


// ========== AUTO FILTER STATUS + SEARCH DI DAFTAR ALAT ==========
document.addEventListener('DOMContentLoaded', () => {
  const statusSelect = document.getElementById('statusSelect');
  const searchInput  = document.getElementById('searchInput');

  // Kalau ini bukan halaman daftar-alat, langsung keluar
  if (!statusSelect || !searchInput) return;

  function applyFilter() {
    const params = new URLSearchParams(window.location.search);

    // STATUS
    const statusVal = statusSelect.value || 'Semua Status';
    params.set('status', statusVal);

    // SEARCH
    const text = searchInput.value.trim();
    if (text !== '') {
      params.set('search', text);
    } else {
      params.delete('search');
    }

    const baseUrl = window.location.pathname; // contoh: /admin/daftar-alat
    window.location.href = baseUrl + '?' + params.toString();
  }

  // ganti status → langsung filter
  statusSelect.addEventListener('change', applyFilter);

  // ketik di search → auto filter setelah berhenti ngetik sebentar
  let timer = null;
  searchInput.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(applyFilter, 400); // 0.4 detik
  });
});
