document.addEventListener('DOMContentLoaded', () => {
  const panel    = document.getElementById('detailPanel');
  const closeEl  = document.getElementById('closeDetail');
  if (!panel || !closeEl) return;

  // 🔥 ELEMENTS BARU untuk status & submit
  const statusDisplay = panel.querySelector('#statusDisplay');
  const fotoStatus = panel.querySelector('#fotoStatus');
  const kondisiStatus = panel.querySelector('#kondisiStatus');
  const btnSubmit = panel.querySelector('#btnSubmitPengembalian');
  const form = document.getElementById('formTerimaPengembalian');

  const setText = (selector, value) => {
    const el = panel.querySelector(selector);
    if (el) el.textContent = (value ?? '-') || '-';
  };

  const uploadWrapper = panel.querySelector('.upload-wrapper');
  const fileInput     = panel.querySelector('input[name="foto_serah_terima"]');
  const selectKondisi = panel.querySelector('select[name="kondisi_barang"]');
  const imgPreview    = panel.querySelector('.d-foto-serah-terima');

  const hide = (el) => { if (el) el.style.display = 'none'; };
  const show = (el) => { if (el) el.style.display = ''; };

  // 🔥 FUNCTION: Update Status Real-time (BARU!)
  function updateFormStatus() {
    if (!statusDisplay || !fotoStatus || !kondisiStatus || !btnSubmit) return;

    const fotoFile = fileInput?.files[0];
    const kondisiValue = selectKondisi?.value?.trim();
    const adaFotoLama = imgPreview?.style.display !== 'none';

    // Update foto status
    if (fotoFile || adaFotoLama) {
      fotoStatus.innerHTML = '📷 <strong>Foto OK</strong>';
      fotoStatus.className = 'foto-status success';
    } else {
      fotoStatus.innerHTML = '📷 Belum ada foto';
      fotoStatus.className = 'foto-status pending';
    }

    // Update kondisi status
    if (kondisiValue) {
      kondisiStatus.innerHTML = '✅ <strong>' + kondisiValue + '</strong>';
      kondisiStatus.className = 'kondisi-status success';
    } else {
      kondisiStatus.innerHTML = '✅ Pilih kondisi';
      kondisiStatus.className = 'kondisi-status pending';
    }

    // 🔥 LOGIKA STATUS UTAMA & TOMBOL
    const adaFoto = !!(fotoFile || adaFotoLama);
    const adaKondisi = !!kondisiValue;

    if (adaFoto && adaKondisi) {
      // ✅ LENGKAP - DIKEMBALIKAN
      statusDisplay.innerHTML = '✅ <strong>SIAP DIKEMBALIKAN</strong>';
      statusDisplay.className = 'status-display complete';
      btnSubmit.innerHTML = '✅ Konfirmasi Dikembalikan';
      btnSubmit.disabled = false;
      btnSubmit.className = 'btn-submit success';
    } else if (adaFoto || adaKondisi) {
      // ⏳ BELUM LENGKAP - MENUNGGU
      statusDisplay.innerHTML = '⏳ <strong>Menunggu kelengkapan</strong>';
      statusDisplay.className = 'status-display warning';
      btnSubmit.innerHTML = '⏳ Simpan Sementara';
      btnSubmit.disabled = false;
      btnSubmit.className = 'btn-submit warning';
    } else {
      // 📤 KOSONG - DIPINJAM
      statusDisplay.innerHTML = '📤 Silakan upload foto & pilih kondisi';
      statusDisplay.className = 'status-display pending';
      btnSubmit.disabled = true;
      btnSubmit.className = 'btn-submit disabled';
    }
  }

  // 🔥 EVENT LISTENER untuk real-time update
  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (file && imgPreview) {
        const reader = new FileReader();
        reader.onload = (e) => {
          imgPreview.src = e.target.result;
          imgPreview.style.display = 'block';
          imgPreview.style.border = '2px solid #3b82f6'; // biru untuk foto baru
          uploadWrapper?.classList.add('complete');
        };
        reader.readAsDataURL(file);
      }
      updateFormStatus(); // 🔥 UPDATE STATUS
    });
  }

  if (selectKondisi) {
    selectKondisi.addEventListener('change', updateFormStatus); // 🔥 UPDATE STATUS
  }

  // buka panel (EXISTING + TAMBAHAN)
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn-detail');
    if (!btn) return;

    // isi data umum (EXISTING)
    setText('.d-nama',          btn.dataset.nama);
    setText('.d-idpegawai',     btn.dataset.idpegawai);
    setText('.d-unit',          btn.dataset.unit);
    setText('.d-notelp',        btn.dataset.notelp);
    setText('.d-barang',        btn.dataset.barang);
    setText('.d-jumlah',        btn.dataset.jumlah);
    setText('.d-ketersediaan',  btn.dataset.ketersediaan);
    setText('.d-keperluan',     btn.dataset.keperluan);
    setText('.d-mulai',         btn.dataset.mulai);
    setText('.d-selesai',       btn.dataset.selesai);

    // 🔥 PHOTO SERAH TERIMA (EXISTING + TAMBAHAN STATUS)
    if (imgPreview) {
      const fotoUrl = btn.dataset.fotoUrl || '';
      if (fotoUrl && fotoUrl.trim()) {
        imgPreview.src = fotoUrl;
        imgPreview.style.display = 'block';
        imgPreview.style.width = '200px';
        imgPreview.style.height = '150px';
        imgPreview.style.objectFit = 'cover';
        imgPreview.style.borderRadius = '8px';
        imgPreview.style.border = '2px solid #10b981'; // hijau untuk foto lama
        uploadWrapper?.classList.add('complete');
      } else {
        imgPreview.src = '';
        imgPreview.style.display = 'none';
        uploadWrapper?.classList.remove('complete');
      }
    }

    // set kondisi selected (EXISTING)
    if (selectKondisi) {
      const kondisiSelected = (btn.dataset.kondisiSelected || '').trim();
      selectKondisi.value = kondisiSelected || 'Baik';
      if (kondisiSelected) {
        selectKondisi.classList.add('complete');
      } else {
        selectKondisi.classList.remove('complete');
      }
    }

    // SET FORM ACTION URL (EXISTING)
    if (form) {
      form.action = btn.dataset.urlTerima;
    }

    // final flag dari server (EXISTING)
    const isFinal = (btn.dataset.final === '1');
    if (isFinal) {
      if (fileInput) fileInput.disabled = true;
      if (selectKondisi) selectKondisi.disabled = true;
      if (btnSubmit) btnSubmit.disabled = true;
    }

    // 🔥 TRIGGER STATUS CHECK AWAL
    panel.classList.add('active');
    document.body.style.overflow = 'hidden';
    setTimeout(updateFormStatus, 100);
  });

  // tutup panel (EXISTING)
  closeEl.addEventListener('click', () => {
    panel.classList.remove('active');
    document.body.style.overflow = 'auto';
  });
  
  window.addEventListener('click', (e) => {
    if (e.target === panel) {
      panel.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  });

  // ESCAPE KEY (EXISTING)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panel.classList.contains('active')) {
      panel.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  });

  // 🔥 FORM SUBMIT HANDLER (UPGRADE DARI EXISTING)
  if (form) {
    form.addEventListener('submit', (e) => {
      const fotoFile = fileInput?.files[0];
      const kondisi = selectKondisi?.value?.trim();
      const adaFotoLama = imgPreview?.style.display !== 'none';
      
      // Validasi minimal 1 ada
      if (!kondisi && !fotoFile && !adaFotoLama) {
        e.preventDefault();
        alert('❌ Harap upload foto ATAU pilih kondisi barang!');
        return false;
      }
      
      // Update button loading
      if (btnSubmit) {
        btnSubmit.innerHTML = '🚀 Mengirim...';
        btnSubmit.disabled = true;
      }
      
      // Konfirmasi final
      if (!confirm('Yakin simpan data pengembalian ini?')) {
        e.preventDefault();
        if (btnSubmit) updateFormStatus(); // reset button
        return false;
      }
    });
  }

  // 🔥 AUTO REFRESH TABEL setelah submit sukses
  window.addEventListener('message', (e) => {
    if (e.data === 'pengembalian_updated') {
      window.location.reload();
    }
  });
});
