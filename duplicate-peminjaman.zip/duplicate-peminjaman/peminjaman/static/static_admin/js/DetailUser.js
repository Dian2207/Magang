// ================== AMBIL ELEMEN PANEL & FORM ==================
const editButtons = document.querySelectorAll('.btn-edit-user');
const detailPanel = document.getElementById('detailPanel');
const closeBtn    = document.getElementById('closeDetail');
const batalBtn    = document.querySelector('.btn-tolak');
const simpanBtn   = document.querySelector('.btn-terima');
const formPegawai = document.getElementById('formPegawai');

const inputNama      = document.getElementById('f_nama');
const inputIdPegawai = document.getElementById('f_idpegawai');
const inputEmail     = document.getElementById('f_email');
const inputUnit      = document.getElementById('f_unit');
const inputNoTelp    = document.getElementById('f_no_telp');  // ⬅ sesuai HTML kamu
const inputUsername  = document.getElementById('f_username');
const inputPassword  = document.getElementById('f_password');
const selectStatus   = document.getElementById('f_status');
const detailAvatar   = document.getElementById('detailAvatar');
const defaultAvatar  = detailAvatar.dataset.defaultSrc;
const baseStaticUrl  = detailAvatar.dataset.baseUrl;   // contoh: "/static_admin/"

const addBtn = document.getElementById('btnAddUser');

// ================== MODE EDIT USER ==================
if (editButtons && detailPanel && formPegawai) {
  editButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const updateUrl = btn.dataset.updateUrl;
      formPegawai.action = updateUrl;

      inputNama.value      = btn.dataset.nama || '';
      inputIdPegawai.value = btn.dataset.idpegawai || '';
      inputEmail.value     = btn.dataset.email || '';
      inputUnit.value      = btn.dataset.unit || '';
      inputNoTelp.value    = btn.dataset.notelp || '';
      inputUsername.value  = btn.dataset.username || '';
      inputPassword.value  = btn.dataset.password || '';
      selectStatus.value   = btn.dataset.status || 'Aktif';

      const profilePhoto = btn.dataset.profilePhoto;
      if (profilePhoto) {
        // contoh: baseStaticUrl = "/static_admin/"
        detailAvatar.src = baseStaticUrl + profilePhoto;
      } else {
        detailAvatar.src = defaultAvatar;
      }

      // reset input file
      const fileInput = document.getElementById('f_profile_photo');
      if (fileInput) fileInput.value = '';

      detailPanel.classList.add('active');
    });
  });
}

// ================== MODE TAMBAH USER ==================
if (addBtn && detailPanel && formPegawai) {
  addBtn.addEventListener('click', () => {
    const addUrl = addBtn.dataset.addUrl;
    formPegawai.action = addUrl;

    // kosongkan semua field
    inputNama.value      = '';
    inputIdPegawai.value = '';
    inputEmail.value     = '';
    inputUnit.value      = '';
    inputNoTelp.value    = '';
    inputUsername.value  = '';
    inputPassword.value  = '';
    selectStatus.value   = 'Aktif';

    detailAvatar.src = defaultAvatar;

    const fileInput = document.getElementById('f_profile_photo');
    if (fileInput) fileInput.value = '';

    detailPanel.classList.add('active');
  });
}

// ================== TOMBOL TUTUP / BATAL / SIMPAN ==================
if (closeBtn && detailPanel) {
  closeBtn.addEventListener('click', () => {
    detailPanel.classList.remove('active');
  });
}

if (batalBtn && detailPanel) {
  batalBtn.addEventListener('click', () => {
    detailPanel.classList.remove('active');
  });
}

if (simpanBtn && formPegawai) {
  simpanBtn.addEventListener('click', () => {
    formPegawai.submit();
  });
}

// ================== FILTER STATUS + SEARCH (MANAGEMEN USER) ==================
const filterStatus = document.getElementById('filterStatus');  // dari HTML kamu
const filterSearch = document.getElementById('filterSearch');

if (filterStatus && filterSearch) {
  function applyFilter() {
    const params = new URLSearchParams(window.location.search);

    // STATUS
    const statusVal = filterStatus.value || 'Semua Status';
    params.set('status', statusVal);

    // SEARCH
    const text = filterSearch.value.trim();
    if (text !== '') {
      params.set('search', text);
    } else {
      params.delete('search');
    }

    const baseUrl = window.location.pathname; // contoh: /admin/manajemen-user
    window.location.href = baseUrl + '?' + params.toString();
  }

  // Ganti status -> langsung filter
  filterStatus.addEventListener('change', applyFilter);

  // Ketik di search -> auto filter setelah berhenti ngetik sebentar
  let timer = null;
  filterSearch.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(applyFilter, 400);  // 0.4 detik
  });
}
