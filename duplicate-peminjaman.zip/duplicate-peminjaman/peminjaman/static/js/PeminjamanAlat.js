// static/js/PeminjamanAlat.js
window.addEventListener('DOMContentLoaded', () => {
  // =========================
  //  TOGGLE FORM "Ajukan Peminjaman"
  // =========================
  const showFormBtn = document.getElementById("showFormBtn");
  const formBox     = document.getElementById("peminjamanForm");

  if (showFormBtn && formBox) {
    showFormBtn.addEventListener("click", function () {
      const isHidden = (formBox.style.display === "none" || formBox.style.display === "");
      formBox.style.display = isHidden ? "block" : "none";

      if (isHidden) {
        formBox.scrollIntoView({ behavior: "smooth" });
      }
    });
  }

  // =========================
  //  HANDLE SUBMIT FORM via /api/peminjaman
  // =========================
  const form  = document.getElementById("formPeminjaman");
  const notif = document.getElementById("notifContainer");

  if (form) {
    form.addEventListener("submit", async function (e) {
      e.preventDefault(); // Cegah reload halaman

      if (!notif) {
        console.warn("Element #notifContainer tidak ditemukan, fallback ke submit biasa.");
        this.submit();
        return;
      }

      // Ambil semua data dari form
      const formData = new FormData(this);

      try {
        // Kirim ke Flask lewat endpoint /api/peminjaman
        const response = await fetch("/api/peminjaman", {
          method: "POST",
          body: formData,
        });

        const result = await response.json();

        if (result.ok) {
          notif.innerHTML = `<div class="alert" style="color:green; font-weight:bold;">${result.message}</div>`;
          notif.style.display = "block";
          this.reset();

          // Sembunyikan form setelah 2 detik
          setTimeout(() => {
            formBox.style.display = "none";
            notif.style.display = "none";
          }, 2000);
        } else {
          notif.innerHTML = `<div class="alert" style="color:red; font-weight:bold;">${result.message}</div>`;
          notif.style.display = "block";
        }
      } catch (error) {
        console.error("Fetch Error:", error);
        notif.innerHTML = `<div class="alert" style="color:red; font-weight:bold;">Terjadi kesalahan koneksi ke server.</div>`;
        notif.style.display = "block";
      }
    });
  }

  // =========================
  //  TOGGLE NAVBAR (HAMBURGER) – kalau mau sekalian
  // =========================
  const menuBtn = document.querySelector('.menu-toggle');
  const navbar  = document.querySelector('.navbar');

  if (menuBtn && navbar) {
    menuBtn.addEventListener('click', function () {
      navbar.classList.toggle('nav-open');
    });
  }

  // =========================
  //  INIT AUTOCOMPLETE PRODUK (jika function-nya ada)
  // =========================
  if (window.initProductAutocomplete) {
    window.initProductAutocomplete();
  }
});
