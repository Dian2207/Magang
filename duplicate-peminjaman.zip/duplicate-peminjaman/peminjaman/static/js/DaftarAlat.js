// static/js/DaftarAlat.js

function applyFilters() {
  const select  = document.getElementById('filterStatus');
  const inputEl = document.getElementById('searchInput');

  const filter  = (select?.value || 'semua').toLowerCase();   // status
  const keyword = (inputEl?.value || '').toLowerCase();       // nama barang

  document.querySelectorAll('.equipment-row').forEach(row => {
    const status = (row.dataset.status || '').toLowerCase();
    const name   = (row.children[2]?.textContent || '').toLowerCase(); // kolom nama barang

    const matchStatus = (filter === 'semua' || status === filter);
    const matchName   = (!keyword || name.includes(keyword));

    row.style.display = (matchStatus && matchName) ? '' : 'none';
  });
}

function filterTable() {
  applyFilters();
}

function searchTable() {
  applyFilters();
}
