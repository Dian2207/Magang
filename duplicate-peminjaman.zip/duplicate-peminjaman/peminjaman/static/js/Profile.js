const editBtn  = document.getElementById('editProfileBtn');
const cancelBtn = document.getElementById('batalBtn');
const form     = document.getElementById('profileForm');
const inputs   = form.querySelectorAll('input');
const btnGroup = document.getElementById('editButtons');
const logoutBtn = document.getElementById('logoutBtn');

let initialValues = {};

// Muat data dari localStorage (jika ada)
(function loadFromStorage() {
  const saved = localStorage.getItem('profileData');
  if (!saved) return;
  try {
    const data = JSON.parse(saved);
    inputs.forEach(inp => {
      if (data[inp.name] !== undefined) inp.value = data[inp.name];
    });
  } catch(e) {}
})();

function enableEdit() {
  initialValues = {};
  inputs.forEach(input => {
    initialValues[input.name] = input.value;
    if (input.name !== "idPegawai") {
      input.removeAttribute('readonly');
      input.style.background = '#fff';
    }
  });
  btnGroup.style.display = 'flex';
  editBtn.style.display = 'none';
  logoutBtn.style.display = 'none'; // 🔹 Sembunyikan tombol logout
}

function cancelEdit() {
  inputs.forEach(input => {
    input.value = initialValues[input.name];
    input.setAttribute('readonly', true);
    input.style.background = '';
  });
  btnGroup.style.display = 'none';
  editBtn.style.display = 'inline-block';
  logoutBtn.style.display = 'block'; // 🔹 Tampilkan lagi tombol logout
}

function saveAndLock(e) {
  e.preventDefault();
  const data = {};
  inputs.forEach(inp => data[inp.name] = inp.value);
  localStorage.setItem('profileData', JSON.stringify(data));
  inputs.forEach(inp => inp.setAttribute('readonly', true));
  btnGroup.style.display = 'none';
  editBtn.style.display = 'inline-block';
  logoutBtn.style.display = 'block'; // 🔹 Munculkan lagi setelah simpan
  alert('Profil tersimpan di perangkat ini.');
}

editBtn.addEventListener('click', enableEdit);
cancelBtn.addEventListener('click', cancelEdit);
form.addEventListener('submit', saveAndLock);

// Tambahan fungsi logout (dummy)
logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('profileData');
  alert('Anda telah logout!');
  window.location.href = 'login.html'; // ubah sesuai halaman login kamu
});
