// static/js/Pengembalian.js
window.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('popupModal');
  const body  = document.body;

  // =========================
  //  BUKA MODAL PENGEMBALIAN
  // =========================
  document.querySelectorAll('.equipment-row .aksi-btn img').forEach((btn) => {
    btn.addEventListener('click', function () {
      const row = this.closest('.equipment-row');
      if (!row) return;

      const idPengajuan  = row.dataset.id || '';
      const kode         = row.dataset.kode || row.dataset.productId || '';
      const namaBarang   = row.dataset.nama || '';
      const kategori     = row.dataset.kategori || '';
      const jumlah       = row.dataset.jumlah || '';
      const sedia        = row.dataset.ketersediaan || '';
      const keperluan    = row.dataset.keperluan || '';
      const tMulai       = row.dataset.tanggal_mulai || '';
      const namaPeminjam = row.dataset.nama_peminjam || '';
      const idPegawai    = row.dataset.id_pegawai || '';
      const unit         = row.dataset.unit || '';
      const telp         = row.dataset.no_telp || '';

      // Isi field tersembunyi utk backend
      const idPengajuanEl = document.getElementById('idPengajuan');
      if (idPengajuanEl) idPengajuanEl.value = idPengajuan;

      // Data peminjam
      const namaPeminjamEl = document.getElementById('namaPeminjam');
      const idPegawaiEl    = document.getElementById('idPegawai');
      const unitEl         = document.getElementById('unit');
      const telpEl         = document.getElementById('noTelp');

      if (namaPeminjamEl) namaPeminjamEl.value = namaPeminjam;
      if (idPegawaiEl)    idPegawaiEl.value    = idPegawai;
      if (unitEl)         unitEl.value         = unit;
      if (telpEl)         telpEl.value         = telp;

      // Data barang
      const kodeBarangEl     = document.getElementById('kodeBarang');
      const namaBarangEl     = document.getElementById('namaBarang');
      const kategoriBarangEl = document.getElementById('kategoriBarang');
      const jumlahUnitEl     = document.getElementById('jumlahUnit');
      const sediaEl          = document.getElementById('ketersediaan');

      if (kodeBarangEl)     kodeBarangEl.value     = kode;
      if (namaBarangEl)     namaBarangEl.value     = namaBarang;
      if (kategoriBarangEl) kategoriBarangEl.value = kategori;
      if (jumlahUnitEl)     jumlahUnitEl.value     = jumlah;
      if (sediaEl)          sediaEl.value          = sedia;

      const keperluanEl = document.getElementById('keperluan');
      if (keperluanEl) keperluanEl.value = keperluan;

      const tPinjamEl = document.getElementById('tanggalPinjam');
      if (tPinjamEl) tPinjamEl.value = tMulai;

      // Reset field yang diisi user
      const tKembaliEl = document.getElementById('tanggalKembali');
      const kondisiEl  = document.getElementById('kondisiBarang');
      if (tKembaliEl) tKembaliEl.value = '';
      if (kondisiEl)  kondisiEl.value  = '';

      const statusEl = document.getElementById('status');
      if (statusEl) statusEl.value = 'Dikembalikan';

      // Pastikan tombol Kirim & Batal aktif lagi saat modal dibuka
      const submitBtn = document.querySelector('.btn-submit');
      const cancelBtn = document.getElementById('batalBtn');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.style.opacity = '';
        submitBtn.style.cursor = '';
        submitBtn.style.display = '';
      }
      if (cancelBtn) {
        cancelBtn.disabled = false;
        cancelBtn.style.opacity = '';
        cancelBtn.style.cursor = '';
        cancelBtn.style.display = '';
      }

      // Tampilkan modal
      if (modal) {
        modal.classList.add('show');
        body.style.overflow = 'hidden';
      }
    });
  });

  // =========================
  //  TOMBOL BATAL / TUTUP
  // =========================
  const batalBtn = document.getElementById('batalBtn');
  if (batalBtn) {
    batalBtn.addEventListener('click', () => {
      if (modal) modal.classList.remove('show');
      body.style.overflow = '';
    });
  }

  // Klik backdrop (area gelap)
  window.addEventListener('click', (e) => {
    if (modal && e.target === modal) {
      modal.classList.remove('show');
      body.style.overflow = '';
    }
  });

  // ESC untuk tutup modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal && modal.classList.contains('show')) {
      modal.classList.remove('show');
      body.style.overflow = '';
    }
  });

  // =========================
  //  DISABLE + HILANGKAN TOMBOL SAAT SUBMIT
  // =========================
  const formPengembalian = document.getElementById('formPengembalian');
  if (formPengembalian) {
    formPengembalian.addEventListener('submit', function () {
      const submitBtn = formPengembalian.querySelector('.btn-submit');
      const cancelBtn = document.getElementById('batalBtn');

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.style.opacity = '0.6';
        submitBtn.style.cursor = 'not-allowed';
        submitBtn.style.display = 'none';   // ⬅ tombol Kirim hilang
      }

      if (cancelBtn) {
        cancelBtn.disabled = true;
        cancelBtn.style.opacity = '0.6';
        cancelBtn.style.cursor = 'not-allowed';
        cancelBtn.style.display = 'none';   // ⬅ tombol Batal hilang
      }
    });
  }

  // =========================
  //  NAVBAR TOGGLE (MOBILE)
  // =========================
  const menuBtn = document.querySelector('.menu-toggle');
  const navbar  = document.querySelector('.navbar');

  if (menuBtn && navbar) {
    menuBtn.addEventListener('click', function () {
      navbar.classList.toggle('nav-open');
    });
  }
});
