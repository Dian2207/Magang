// static/js/product-autocomplete.js
(function () {
  const debounce = (fn, ms = 200) => {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(null, args), ms);
    };
  };

  function initAuto(input) {
    const targetHiddenId = input.dataset.target; // id input hidden utk product_id

    // Bungkus input agar dropdown bisa absolute
    const wrap = document.createElement("div");
    wrap.style.position = "relative";
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);

    // Elemen daftar
    const list = document.createElement("div");
    list.className = "ac-list";
    Object.assign(list.style, {
      position: "absolute",
      left: 0,
      right: 0,
      top: (input.offsetHeight - 1) + "px",
      background: "#fff",
      border: "1px solid #ccc",
      borderTop: "none",
      borderRadius: "0 0 6px 6px",
      boxShadow: "0 4px 10px rgba(0,0,0,.08)",
      maxHeight: "260px",
      overflowY: "auto",
      zIndex: 1000,
      display: "none"
    });
    wrap.appendChild(list);

    let items = [];
    let activeIndex = -1;

    function selectItem(it) {
      input.value = it.product_name;
      const hidden = document.getElementById(targetHiddenId);
      if (hidden) hidden.value = it.product_id; // set kode barang
      closeList();
    }

    function closeList() {
      list.style.display = "none";
      items = [];
      activeIndex = -1;
      list.innerHTML = "";
    }

    function render() {
      list.innerHTML = "";
      if (!items.length) {
        closeList();
        return;
      }
      items.forEach((it, idx) => {
        const row = document.createElement("div");
        row.className = "ac-item";
        row.style.padding = "10px 12px";
        row.style.cursor = "pointer";
        row.style.borderTop = "1px solid #eee";
        row.style.background = idx === activeIndex ? "#f6f6f6" : "#fff";
        row.innerHTML = `
          <div style="font-weight:600">${it.product_name}</div>
          <div style="font-size:12px;opacity:.8">
            Kode: ${it.product_id} · Stok: ${it.quantity} · ${it.status || "-"}
          </div>
        `;
        row.addEventListener("mousedown", (e) => { // mousedown supaya tidak kalah oleh blur
          e.preventDefault();
          selectItem(it);
        });
        list.appendChild(row);
      });
      list.style.display = "block";
    }

    async function fetchData(q) {
      const res = await fetch(`/api/products/search?q=${encodeURIComponent(q)}&available=1`);
      return await res.json();
    }

    const doSearch = debounce(async () => {
      const q = input.value.trim();
      // Kosongkan kode bila user mengubah teks manual
      const hidden = document.getElementById(targetHiddenId);
      if (hidden) hidden.value = "";
      items = await fetchData(q); // q boleh kosong → ambil top 10
      activeIndex = -1;
      render();
    }, 200);

    // ===== Event handlers =====
    input.addEventListener("input", doSearch);

    // Tampilkan daftar saat fokus/klik (meski belum mengetik)
    async function showOnFocusOrClick() {
      items = await fetchData(input.value.trim());
      activeIndex = -1;
      render();
    }
    input.addEventListener("focus", showOnFocusOrClick);
    input.addEventListener("click", showOnFocusOrClick);

    // Keyboard navigation
    input.addEventListener("keydown", (e) => {
      if (list.style.display !== "block") return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        activeIndex = Math.min(activeIndex + 1, items.length - 1);
        render();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        activeIndex = Math.max(activeIndex - 1, 0);
        render();
      } else if (e.key === "Enter") {
        if (activeIndex >= 0 && items[activeIndex]) {
          e.preventDefault();
          selectItem(items[activeIndex]);
        }
      } else if (e.key === "Escape") {
        closeList();
      }
    });

    // Tutup saat klik di luar
    document.addEventListener("click", (e) => {
      if (!wrap.contains(e.target)) closeList();
    });

    // Sinkronkan posisi saat resize
    window.addEventListener("resize", () => {
      list.style.top = (input.offsetHeight - 1) + "px";
    });
  }

  // Auto-init semua input yang punya data-autocomplete="product"
  window.initProductAutocomplete = function () {
    document.querySelectorAll('input[data-autocomplete="product"]').forEach(initAuto);
  };
})();
